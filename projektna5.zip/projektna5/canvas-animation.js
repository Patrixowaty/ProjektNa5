var canvas = document.querySelector("#canvas");
var ctx = canvas.getContext("2d");

var image = new Image();
image.src = "jet.png";

var x = -100;
var y = canvas.height / 2;

var amplitude = 30;
var frequency = 0.02;
var speed = 2;

function drawImage() {
  ctx.clearRect(0, 0, canvas.width, canvas.height);

  x += speed;
  y = canvas.height / 2 + Math.sin(x * frequency) * amplitude;

  ctx.drawImage(image, x, y, 100, 70);

  if (x < canvas.width) {
    requestAnimationFrame(drawImage);
  } else {
    x = 0;
    y = canvas.height / 2;

    requestAnimationFrame(drawImage);
  }
}

image.onload = function() {
  drawImage();
};