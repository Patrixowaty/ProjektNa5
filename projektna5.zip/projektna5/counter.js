var display = document.querySelectorAll(".param strong");
var interval = 4000;

console.log(display)

display.forEach((display) => {
    var startValue = 0;
    var endValue = parseInt(display.getAttribute("data-val"));
    var duration = Math.floor(interval / endValue);
    var counter = setInterval(() => {
        startValue += 1;
        display.textContent = startValue;

        if (startValue == endValue) {
            clearInterval(counter);    
        }
    }, duration);
});