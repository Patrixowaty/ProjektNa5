var lat1, lon1, lat2, lon2;

function getLocation() {
    if (navigator.geolocation) {
        navigator.geolocation.getCurrentPosition((position) => {
            lat1 = position.coords.latitude;
            lon1 = position.coords.longitude;

            var select = document.querySelector("#miasto").value;

            switch (select) {
                case "paryz":
                    lat2 = 48.864716;
                    lon2 = 2.349014;
                    break;
                case "warszawa":
                    lat2 = 52.237049;
                    lon2 = 21.017532;
                    break;
                case "pekin":
                    lat2 = 39.916668;
                    lon2 = 116.383331;
                    break;
                case "ankara":
                    lat2 = 39.925533;
                    lon2 = 32.866287;
                    break;
                case "madryt":
                    lat2 = 40.416775;
                    lon2 = -3.703790;
                    break;
            }
                
            console.log(lat1 + " | " + lon1 + "\n" + lat2 + " | " + lon2);

            function haversine(lat1, lon1, lat2, lon2) {
                let dLat = (lat2 - lat1) * Math.PI / 180.0;
                let dLon = (lon2 - lon1) * Math.PI / 180.0;
                
                lat1 = (lat1) * Math.PI / 180.0;
                lat2 = (lat2) * Math.PI / 180.0;
                
                let a = Math.pow(Math.sin(dLat / 2), 2) +
                        Math.pow(Math.sin(dLon / 2), 2) *
                        Math.cos(lat1) *
                        Math.cos(lat2);
                let rad = 6371;
                let c = 2 * Math.asin(Math.sqrt(a));
                return rad * c;
            }

            var t,
                S = haversine(lat1, lon1, lat2, lon2), 
                V = 2130;
            
            t = S / V;

            var wynik = document.querySelector("form #wynik");

            wynik.innerHTML = (t.toFixed(1) * 60 + " min.");
        });
    }
}